from django.db import models


class User(models.Model):
    id_user=models.AutoField(primary_key=True)  
    nombre=models.CharField(max_length=100)
    nickname=models.CharField(max_length=100)
    contraseña=models.CharField(max_length=100)
    correo=models.EmailField(max_length=140)
    f_nacimiento=models.DateField()

class Genero(models.Model):
    id_genero=models.AutoField(primary_key=True)  
    name = models.CharField(max_length=30)

class Desarrollador(models.Model):
    id_desarrollador=models.AutoField(primary_key=True)  
    name = models.CharField(max_length=30 )


class Juegos(models.Model):
    id_juego=models.AutoField(primary_key=True)       
    name = models.CharField(max_length=30)      
    imagen = models.CharField(max_length=1500, default="https://plantillasdememes.com/img/plantillas/imagen-no-disponible01601774755.jpg")    
    genero = models.IntegerField() 
    descripcion = models.CharField(max_length=3000, blank=True)
    fecha_lanzamiento = models.DateField()


