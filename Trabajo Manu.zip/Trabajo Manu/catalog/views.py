from django.shortcuts import render
from catalog.models import *
from django.template import Template, Context, loader
from django.http import HttpResponse
"""
from django.contrib.auth import get_user_model
# Create your views here.

User = get_user_model()
"""
def index(request):
    busqJuegos=Juegos.objects.all()
    if ("usuario" in request.session):
        inicio = True
    else:
        inicio = False
    return render(request, "index.html", {"juego": busqJuegos, "user" : inicio})

def juegos(request):
    pass

def ficha(request):
    if (request.method=="GET" and request.GET['id']):
        busqJuegos = Juegos.objects.filter(id_juego=request.GET["id"])
        if ("usuario" in request.session):
            inicio = True
        else:
            inicio = False
        return render(request, "ficha.html", {"juego": busqJuegos, "user" : inicio})

def buscar_ficha(request):
        #Comprueba que estas iniciado sesion y que el metodo de envio sea GET 
    if (request.GET["ficha"]):
        busq=request.GET["ficha"]
        #Busca las tiendas en las que hay coincidencias
        juegos=Juegos.objects.filter(name__icontains=busq)
        return render(request, "index.html", {"juego": juegos})

def login(request):
     #Comprueba si está iniciado sesion y si es TRUE te manda al home
    if ("usuario" in request.session and "password" in request.session):
        return render(request, "redirs.html", {"to":"index"})
    #Comprueba que el metodo enviado sea POST
    if request.method=="POST":
        nickname = request.POST['user']
        password = request.POST['password']
        #Comprueba que user y password tengan datos
        if (nickname and password):
            #Compara los datos introducidos con la base de datos si son ciertos sig = True
            try:
                persona = User.objects.get(nickname=nickname)
                sig = True
                x = User.objects.filter(nickname=nickname)
                for art in x : pas = art.contraseña
            #En caso de no coincidir sig = False
            except User.DoesNotExist:
                persona = None
                sig = False
            #Si el usuario existe y las contraseñas coinciden
            if (sig==True and pas == password):
                #Crea las sesiones de usuario y contraseña y te manda al gome
                request.session['usuario'] = nickname
                request.session['password'] = password
                request.session.modified = True
                return render(request, "redirs.html", {"to":"index"})
            else:
                pass #Contraseña incorrecta
    return render(request, "login.html")

#Views Registro //Insertar en views//

def logout(request):
    #Comprueba que estas iniciado sesion
    if ("usuario" in request.session and "password" in request.session):
        #Destruye las sesiones y te manda al index
        del request.session['usuario']
        del request.session['password']
        return render(request, "redirs.html", {"to":"index"})
    else:
        return render(request, "redirs.html", {"to":"index"})

def registro(request):
    #Comprueba si está iniciado sesion y si es TRUE te manda al home
    if ("usuario" in request.session and "password" in request.session):
        return render(request, "redirs.html", {"to":"index"})

    if (request.method=="POST" and request.POST['nombre'] and request.POST['nickname'] and request.POST['password'] and request.POST['email'] and request.POST['fecha_nacimiento']):
        #Asignan valor a los POSTS
        nombre = request.POST['nombre']
        nickname = request.POST['nickname']
        password = request.POST['password']
        email = request.POST['email']
        fecha_n = request.POST['fecha_nacimiento']

        if (nombre and nickname and password and email and fecha_n):
            try:
                #Comprueba que el user existe si es asi sig = False
                persona = User.objects.get(nickname=nickname)
                sig = False
                #Si el user no existe sig = True
            except User.DoesNotExist:
                persona = None
                sig = True
            #Si el user no existe te crea el usuario crea las sesiones y te manda al home
            if (sig == True):
                p = User(nombre=nombre, nickname=nickname, contraseña=password, correo=email, f_nacimiento=fecha_n)
                p.save()
                request.session['usuario'] = nickname
                request.session['password'] = password
                request.session.modified = True


                return render(request, "redirs.html", {"to":"index"})
            #Si el user existe te manda al registro
            else:
                return render(request, "redirs.html", {"to":"registro"})
        #Si no se ha enviado alguno de los metodos por POST
        else:
            return render(request, "redirs.html", {"to":"registro"})
    return render(request, "register.html")

def prb (request):
    if ("usuario" in request.session and "password" in request.session):
        return render(request, "redirs.html", {"to":"index"})
    else:
        return render(request, "redirs.html", {"to":"registro"})

def edicion_juegos (request):
    if ("usuario" in request.session and "password" in request.session):
        if (request.method=="POST" and request.POST['name'] and request.POST['genero'] and request.POST['f_lanz'] and request.POST['imagen'] and request.POST['descripcion']):

            Juegos.objects.filter(id_juego=request.session["idjuego"]).update(name=request.POST['name'], imagen=request.POST['imagen'], genero=request.POST['genero'], descripcion=request.POST['descripcion'], fecha_lanzamiento=request.POST['f_lanz'])
        busqJuegos=Juegos.objects.all()
        return render(request, "edition.html", {"juego": busqJuegos})
    else:
        return render(request, "redirs.html", {"to":"index"})

def borrar_juego (request):
    Juegos.objects.filter(id_juego=request.GET["id"]).delete()
    return render(request, "redirs.html", {"to":"edicion_juego"})

def modifi_juego (request):
    if ("usuario" in request.session and "password" in request.session):
        if (request.GET["id"]):
            #crear sesion
            request.session['idjuego'] = request.GET["id"]
            request.session.modified = True
            busqJuegos=Juegos.objects.filter(id_juego=request.session['idjuego'])
            return render(request, "formulario.html", {"juego": busqJuegos})
        else:
            return render(request, "redirs.html", {"to":"edicion_juego"})
    else:
        return render(request, "redirs.html", {"to":"index"})

def añadir_juego(request):
    if ("usuario" in request.session and "password" in request.session):
        if (request.method=="POST" and request.POST['name'] and request.POST['genero'] and request.POST['f_lanz'] and request.POST['imagen'] and request.POST['descripcion']):
            name = request.POST['name']
            f_lanz = request.POST['f_lanz']
            genero = request.POST['genero']
            imagen = request.POST['imagen']
            descripcion = request.POST['descripcion']
            j = Juegos(name=name, imagen=imagen, genero=int(genero), descripcion=descripcion, fecha_lanzamiento=f_lanz)
            j.save()
            return render(request, "redirs.html", {"to":"edicion_juego"})
        return render(request, "new_juego.html")
    else:
        return render(request, "redirs.html", {"to":"index"})